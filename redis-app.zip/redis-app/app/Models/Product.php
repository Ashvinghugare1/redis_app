<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    public function run(): void
    {
        Product::factory()
                ->count(1000)
                ->hasProducts(1)
                ->create();
    }
}

